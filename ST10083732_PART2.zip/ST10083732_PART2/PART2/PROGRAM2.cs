﻿class Program
{
    static List<Recipe> recipes = new List<Recipe>();

    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("1. Add Recipe");
            Console.WriteLine("2. List All Recipes");
            Console.WriteLine("3. Display Recipe");
            Console.WriteLine("4. Exit");
            Console.WriteLine("Choose an option:");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddRecipe();
                    break;
                case "2":
                    ListRecipes();
                    break;
                case "3":
                    DisplayRecipe();
                    break;
                case "4":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please choose again.");
                    break;
            }
        }
    }

    static void AddRecipe()
    {
        Console.WriteLine("Enter recipe name:");
        string recipeName = Console.ReadLine();
        Recipe recipe = new Recipe(recipeName);

        Console.WriteLine("Enter number of ingredients:");
        int numIngredients = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine($"Enter name of ingredient {i + 1}:");
            string ingredientName = Console.ReadLine();

            Console.WriteLine($"Enter calories of ingredient {i + 1}:");
            int calories = Convert.ToInt32(Console.ReadLine());

            recipe.AddIngredient(ingredientName, calories);
        }

        recipes.Add(recipe);
        Console.WriteLine("Recipe added successfully!");
    }

    static void ListRecipes()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes available.");
            return;
        }

        Console.WriteLine("List of Recipes:");
        foreach (var recipe in recipes.OrderBy(r => r.Name))
        {
            Console.WriteLine($"- {recipe.Name}");
        }
    }

    static void DisplayRecipe()
    {
        Console.WriteLine("Choose a recipe to display:");
        ListRecipes();
        string recipeName = Console.ReadLine();

        Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
        if (recipe != null)
        {
            Console.WriteLine();
            recipe.DisplayRecipe();
        }
        else
        {
            Console.WriteLine("Recipe not found.");
        }
    }
}