﻿using System;
using System.Collections.Generic;
using System.Linq;

class Ingredient
{
    public string Name { get; set; }
    public int Calories { get; set; }
}